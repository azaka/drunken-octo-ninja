#ifndef SIO_H
#define SIO_H

#define SIO_IOCTL_SET_BAUD_RATE 1

extern int registerSIODriver(void);

#endif
