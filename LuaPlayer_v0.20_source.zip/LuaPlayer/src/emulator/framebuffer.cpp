#include <psptypes.h>
#include "../graphics.h"
Color* g_vram_base;

