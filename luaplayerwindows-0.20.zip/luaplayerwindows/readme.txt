- start Lua Player for Windows from command prompt with "luaplayer yourscript.lua"
  check the *.lua files for some working examples

- hit Escape for exit

- keyboard mapping:
  SELECT = a
  START = s
  LTRIGGER = q
  RTRIGGER = w
  TRIANGLE = r
  CIRCLE = f
  CROSS = c
  SQUARE = d
  directional pad = cursor keys
