#define QT_NO_ALSA 
#define QT_NO_DIRECTSHOW 
#define QT_NO_EVR 
#define QT_NO_OPENAL 
#define QT_NO_PULSEAUDIO 
#define QT_NO_WSHELLITEM 
