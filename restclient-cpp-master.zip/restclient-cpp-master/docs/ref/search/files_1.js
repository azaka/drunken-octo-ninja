var searchData=
[
  ['helpers_2eh',['helpers.h',['../helpers_8h.html',1,'']]]
];
