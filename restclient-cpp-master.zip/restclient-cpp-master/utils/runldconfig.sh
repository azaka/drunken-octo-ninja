#!/bin/sh
/sbin/ldconfig
